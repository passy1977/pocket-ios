//
//  ViewController.m
//  KeyboardTextFieldDemo

#import "ScrollViewController.h"

@interface ScrollViewController ()<UIPopoverPresentationControllerDelegate>
{
    IBOutlet UIScrollView *scrollViewDemo;
    IBOutlet UITableView *simpleTableView;
    IBOutlet UIScrollView *scrollViewOfTableViews;
    IBOutlet UITableView *tableViewInsideScrollView;
    IBOutlet UIScrollView *scrollViewInsideScrollView;
    
    
    IBOutlet UITextField *topTextField;
    IBOutlet UITextField *bottomTextField;
    
    IBOutlet UITextView *topTextView;
    IBOutlet UITextView *bottomTextView;
}

@end

@implementation ScrollViewController

#pragma mark - View lifecycle

-(void)dealloc
{
    topTextField = nil;
    bottomTextField = nil;
    topTextView = nil;
    bottomTextView = nil;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 5;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *identifier = [NSString stringWithFormat:@"%ld%ld",(long)indexPath.section,(long)indexPath.row];
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
        cell.backgroundColor = [UIColor clearColor];
        
        CGRect textFieldRect = CGRectInset(cell.contentView.bounds, 5, 5);
        UITextField *textField = [[UITextField alloc] initWithFrame:textFieldRect];
        textField.autoresizingMask = UIViewAutoresizingFlexibleBottomMargin|UIViewAutoresizingFlexibleTopMargin|UIViewAutoresizingFlexibleWidth;
        [textField setPlaceholder:identifier];
        [textField setBorderStyle:UITextBorderStyleRoundedRect];
        [cell.contentView addSubview:textField];
    }

    return cell;
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString:@"SettingsNavigationController"])
    {
        segue.destinationViewController.modalPresentationStyle = UIModalPresentationPopover;
        segue.destinationViewController.popoverPresentationController.barButtonItem = sender;
        
        CGFloat heightWidth = MAX(CGRectGetWidth([[UIScreen mainScreen] bounds]), CGRectGetHeight([[UIScreen mainScreen] bounds]));
        segue.destinationViewController.preferredContentSize = CGSizeMake(heightWidth, heightWidth);
        segue.destinationViewController.popoverPresentationController.delegate = self;
    }
}

- (UIModalPresentationStyle)adaptivePresentationStyleForPresentationController:(UIPresentationController *)controller
{
    return UIModalPresentationNone;
}

-(void)prepareForPopoverPresentation:(UIPopoverPresentationController *)popoverPresentationController
{
    [self.view endEditing:YES];
}

- (BOOL)shouldAutorotate
{
    return YES;
}

@end
