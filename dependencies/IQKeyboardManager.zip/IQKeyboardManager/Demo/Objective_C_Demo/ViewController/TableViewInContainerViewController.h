//
//  TableViewInContainerViewController.h
//  IQKeyboard
//
//  Created by Jeffrey Sambells on 2014-12-05.
//  Copyright (c) 2014 Iftekhar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewInContainerViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>

@end
