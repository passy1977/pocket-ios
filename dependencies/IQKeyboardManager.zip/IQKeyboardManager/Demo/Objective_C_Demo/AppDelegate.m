//
//  AppDelegate.m
//
//  Created by Mohd Iftekhar Qurashi on 01/07/13.


#import "AppDelegate.h"

@implementation AppDelegate

@synthesize window = _window;

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    return YES;
}

@end
