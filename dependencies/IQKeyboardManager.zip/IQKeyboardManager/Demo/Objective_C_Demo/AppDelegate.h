//
//  AppDelegate.h
//
//  Created by Mohd Iftekhar Qurashi on 01/07/13.

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
