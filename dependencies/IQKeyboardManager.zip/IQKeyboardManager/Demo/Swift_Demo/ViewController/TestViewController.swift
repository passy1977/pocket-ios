//
//  TestViewController.swift
//  DemoSwift
//
//  Created by Iftekhar on 7/11/23.
//  Copyright © 2023 Iftekhar. All rights reserved.
//

import UIKit

class TestViewController: BaseViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
