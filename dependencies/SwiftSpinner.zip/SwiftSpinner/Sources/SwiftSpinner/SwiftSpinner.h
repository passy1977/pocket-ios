//
//  SwiftSpinner.h
//  SwiftSpinner
//
//  Created by Doug Woodgate (GE) on 2/19/16.
//  Copyright © 2016 Dwoodgate. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SwiftSpinner.
FOUNDATION_EXPORT double SwiftSpinnerVersionNumber;

//! Project version string for SwiftSpinner.
FOUNDATION_EXPORT const unsigned char SwiftSpinnerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwiftSpinner/PublicHeader.h>


