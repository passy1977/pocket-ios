//
//  AppDelegate.swift
//  ReachabilityMacSample
//
//  Created by Reda Lemeden on 28/11/2015.
//  Copyright © 2015 Ashley Mills. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {
  func applicationDidFinishLaunching(_ aNotification: Notification) {
  }

  func applicationWillTerminate(_ aNotification: Notification) {
  }
}
