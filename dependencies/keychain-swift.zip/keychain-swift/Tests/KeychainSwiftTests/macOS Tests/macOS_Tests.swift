import XCTest
@testable import KeychainSwift

class macOS_Tests: XCTestCase {
        
    override func setUp() {
        super.setUp()
    }
    
    override func tearDown() {
        super.tearDown()
    }
    
    func testExample() {
      XCTAssertTrue(true)
    }
    
}
